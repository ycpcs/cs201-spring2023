import static org.junit.Assert.*;

import org.junit.Test;

public class Q7Test {
	@Test
	public void testCountTall1() throws Exception {
		assertEquals(5, Q9.countTall("Hello, world!"));
	}
	
	@Test
	public void testCountTall2() throws Exception {
		assertEquals(7, Q7.countTall("abcdefghijklmnopqrstuvwxyz"));
	}
	
	@Test
	public void testCountTall3() throws Exception {
		assertEquals(0, Q7.countTall(""));
	}
	
	@Test
	public void testCountTall4() throws Exception {
		assertEquals(10, Q7.countTall("O Michigan, exemplar of unchecked replication"));
	}
	
	@Test
	public void testCountTall5() throws Exception {
		assertEquals(10, Q7.countTall("I! I! Cthulhu fhtagn!"));
	}
	
	@Test
	public void testCountTall6() throws Exception {
		assertEquals(11, Q7.countTall("and now for something completely different"));
	}
}
