public class Q7 {
	// IMPORTANT: you MUST use recursion to implement this method.
	
	public static int countTall(String s) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
