public class Q7 {
	// IMPORTANT: you MUST use recursion to implement this method.
	/*This program is using no loop by calling the function itself. You may do the same program using a loop
*/
	public static int countTall(String s) {
		if (s.equals("")) {
			// base case
			return 0;
		}
		int total = 0;
		char first = s.charAt(0);
		if ("bdfhklt".indexOf(first) >= 0 || Character.isUpperCase(first)) {
			// first character is tall
			total++;
		}
		// tally remaining tall characters recursively
		total += countTall(s.substring(1));
		return total;
	}
}
