import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class Q8 {
	// Create a new (empty) Stats object,
	// read data from stats.csv, and call the updateStats
	// method for each data record.
	// DO NOT MODIFY THIS METHOD.
	// Also, do not modify stats.csv.

	public static Stats readStats() {
		Stats stats = new Stats();
		
		InputStream in = Q10.class.getClassLoader().getResourceAsStream("stats.csv");
		if (in == null) {
			throw new IllegalStateException("Can't find stats.csv");
		}
		BufferedReader r = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
		try {
			try {
				while (true) {
					String line = r.readLine();
					if (line == null) {
						break;
					}
					line = line.trim();
					if (!line.equals("")) {
						String[] fields = line.split(",");
						if (fields.length == 3) {
							stats.updateStats(fields[0], Integer.parseInt(fields[1]), Integer.parseInt(fields[2]));
						}
					}
				}
			} catch (IOException e) {
				throw new IllegalStateException("Exception reading from stats.csv", e);
			}
		} finally {
			try {
				r.close();
			} catch (IOException e) {
				// should not happen
			}
		}
		
		return stats;
	}
}
