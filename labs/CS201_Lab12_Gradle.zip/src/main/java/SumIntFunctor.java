public class SumIntFunctor implements Functor<Integer> {
	// TODO: field(s)
	
	public SumIntFunctor() {
		// TODO: initialize field(s)
	}
	
	@Override
	public void apply(Integer value) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the sum of all Integer values seen by this functor
	 */
	public int getSum() {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
