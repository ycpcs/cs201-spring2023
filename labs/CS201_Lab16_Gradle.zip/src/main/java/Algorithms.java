import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Algorithms {
	public static<E extends Comparable<E>> E findMin(Collection<E> c) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public static<E> E findMin(Collection<E> c, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO - implement");
	}

	public static<E extends Comparable<E>> E findMax(Collection<E> c) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public static<E> E findMax(Collection<E> c, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public static<E> int sequentialSearch(List<E> list, E searchVal) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
