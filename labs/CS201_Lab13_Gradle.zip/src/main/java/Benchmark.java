public class Benchmark {
	public static void main(String[] args) {
		// TODO: benchmark removing all elements from an ArrayList
		// using two techniques
		//
		//   - repeatedly removing the last element
		//   - repeatedly removing the first element
		//
		// Measure the time to remove 10,000, 20,000, etc. elements,
		// up to 100,000 elements, for each technique.
		
	}
}
